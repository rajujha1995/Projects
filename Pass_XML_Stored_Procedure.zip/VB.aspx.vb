﻿
Imports System.IO
Imports System.Data
Imports System.Configuration
Imports System.Data.SqlClient


Partial Class VB
    Inherits System.Web.UI.Page

    Protected Sub UploadXML(sender As Object, e As EventArgs)
        Dim fileName As String = Path.GetFileName(FileUpload1.PostedFile.FileName)
        Dim filePath As String = Server.MapPath("~/Uploads/") & fileName
        FileUpload1.SaveAs(filePath)
        Dim xml As String = File.ReadAllText(filePath)
        Dim constr As String = ConfigurationManager.ConnectionStrings("constr").ConnectionString
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand("InsertXML")
                cmd.Connection = con
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.AddWithValue("@xml", xml)
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        End Using
    End Sub

End Class
