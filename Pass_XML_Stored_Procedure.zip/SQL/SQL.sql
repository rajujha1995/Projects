
/****** Object:  Table [dbo].[CustomerDetails]    Script Date: 8/8/2014 6:25:14 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[CustomerDetails](
	[CustomerId] [int] NOT NULL,
	[Name] [varchar](100) NOT NULL,
	[Country] [varchar](50) NOT NULL,
 CONSTRAINT [PK_CustomerDetails] PRIMARY KEY CLUSTERED 
(
	[CustomerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF

/****** Object:  StoredProcedure [dbo].[InsertXML]    Script Date: 8/8/2014 6:25:23 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--[ParseXML] '<Customers><Customer Id ="1"><Name>JohnHammond</Name><Country>UnitedStates</Country></Customer><Customer Id ="2"><Name>MudassarKhan</Name><Country>India</Country></Customer><Customer Id ="3"><Name>SuzanneMathews</Name><Country>France</Country></Customer><Customer Id ="4"><Name>RobertSchidner</Name><Country>Russia</Country></Customer></Customers>'
CREATE PROCEDURE [dbo].[InsertXML] 
@xml XML
AS
BEGIN
	SET NOCOUNT ON;

	INSERT INTO CustomerDetails
    SELECT 
	Customer.value('@Id','INT') AS Id, --ATTRIBUTE 
	Customer.value('(Name/text())[1]','VARCHAR(100)') AS Name, --TAG 
	Customer.value('(Country/text())[1]','VARCHAR(100)') AS Country --TAG 
	FROM
	@xml.nodes('/Customers/Customer')AS TEMPTABLE(Customer)
END

GO



