﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Users
/// </summary>
public class Users
{
    private string m_name;
    private string m_Email_id;
    private string m_Mobile_No;
    private string m_City;

    public string Name
    {
        get { return m_name; }
        set { m_name = value; }
    }
    public string Email_id
    {
        get { return m_Email_id; }
        set { m_Email_id = value; }
    }
    public string Mobile_No
    {
        get { return m_Mobile_No; }
        set { m_Mobile_No = value; }
    }
    public string City
    {
        get { return m_City; }
        set { m_City = value; }
    }
    
}