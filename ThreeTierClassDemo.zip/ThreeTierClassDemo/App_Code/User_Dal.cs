﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;

/// <summary>
/// Summary description for User_Dal
/// </summary>
public class User_Dal
{
    public static string strConn = WebConfigurationManager.ConnectionStrings["sql"].ConnectionString.ToString();
    public string InsertUser(Users uobj)
    {
        string strResult = string.Empty;
        string strQuery = "sp_Insert_New_User";
        using (SqlConnection con = new SqlConnection(strConn))
        {
            con.Open();
            using (SqlCommand cmd = new SqlCommand(strQuery, con))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Name", uobj.Name);
                cmd.Parameters.AddWithValue("@Email_id", uobj.Email_id);
                cmd.Parameters.AddWithValue("@Mobile_No", uobj.Mobile_No);
                cmd.Parameters.AddWithValue("@City", uobj.City);

                int result = cmd.ExecuteNonQuery();

                if (result >0)
                {
                    strResult = "Success";
                }
                else
                {
                    strResult = "Failure";
                }
            }
        }
        return strResult;
    }
}