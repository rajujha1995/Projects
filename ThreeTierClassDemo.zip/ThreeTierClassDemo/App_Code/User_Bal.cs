﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class User_Bal
{
    public string InsertUsers(Users u_obj)
    {
        User_Dal obj_Dal = new User_Dal();
        return obj_Dal.InsertUser(u_obj); ;
    }

}
