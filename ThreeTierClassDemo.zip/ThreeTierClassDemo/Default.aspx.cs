﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        lblmsg.Text = string.Empty;
        string  strResult= string.Empty;
        Users u_obj = new Users();
        u_obj.Name = txtFname.Text;
        u_obj.Email_id = txtEmail.Text;
        u_obj.Mobile_No = txtMobile.Text;
        u_obj.City = txtCity.Text;

        User_Bal obj_bal = new User_Bal();
       strResult=  obj_bal.InsertUsers(u_obj);
       if (strResult=="Success")
       {
           lblmsg.Text = "Insertion Successfull";
           lblmsg.ForeColor = Color.Green;
       }
       else
       {
           lblmsg.Text = "Insertion UnSuccessfull";
           lblmsg.ForeColor = Color.Red;
       }

    }
}